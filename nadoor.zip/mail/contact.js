const firebaseConfig = {
  apiKey: "AIzaSyBrFCipvm_6Ap7o981TH8Dw98_iFa4whcs",
  authDomain: "nadoor-2fe5e.firebaseapp.com",
  databaseURL: "https://nadoor-2fe5e-default-rtdb.firebaseio.com",
  projectId: "nadoor-2fe5e",
  storageBucket: "nadoor-2fe5e.appspot.com",
  messagingSenderId: "781115285349",
  appId: "1:781115285349:web:bbfa592425d226bfd74b8c"
};

firebase.initializeApp(firebaseConfig);

var contactFormDB = firebase.database().ref('contactForm');


document.getElementById('contactForm').addEventListener("submit",submitForm);

function submitForm(e){
      e.preventDefault();

      var name = getElementVal('name');
      var phno = getElementVal('phno');
      var email = getElementVal('email');
      var subject = getElementVal('subject');
      var message = getElementVal('message');


      console.log(name, phno, email, subject, message);
      //saveMessages(name, phno, email, subject, message);
}

// constsaveMessages = (name, phno, email, subject, message) => {
//   var newContactForm = contactFormDB.push();

//   newContactForm.set({
//     name : name,
//     phno : phno,
//     email : email,
//     subject : subject,
//     message : message,

//   });

// };

const getElementVal = (id) => {
  return document.getElementById(id).value;
};
