// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCb1JgLJyD9fLkbug5ai-3pTtnV9_tayv8",
  authDomain: "nadoor-65874.firebaseapp.com",
  projectId: "nadoor-65874",
  storageBucket: "nadoor-65874.appspot.com",
  messagingSenderId: "292459027294",
  appId: "1:292459027294:web:049051c2ab6b2164040dcf",
  measurementId: "G-LGYZPSWLMK"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

const db = getDatabase(app); // For Realtime Database
const firestore = getFirestore(app); // For Firestore
const auth = getAuth(app); // For Authentication

export { app, db, firestore, auth };